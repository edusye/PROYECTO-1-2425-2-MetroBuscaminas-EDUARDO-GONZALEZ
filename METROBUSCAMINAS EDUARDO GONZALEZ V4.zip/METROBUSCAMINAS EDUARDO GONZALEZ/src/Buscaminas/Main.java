/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Buscaminas;

import GUI.Ventana;

/**
 *
 * @author edusye
 */
public class Main {
    public static void main(String []argas) {
        Ventana v1 = new Ventana();
        v1.setVisible(true);
        v1.setLocationRelativeTo(null);
        
        
    }
}
