/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

import java.awt.BorderLayout;
import javax.swing.JPanel;

/**
 *
 * @author edusye
 */
public final class Ventana extends javax.swing.JFrame {
    private Ventana2 v2;
    private Ventana4 v4;
    private VentanaJuego ventanaJuego;
    
    public Ventana() {
        setUndecorated(true);
        initComponents();
        Ventana1 v1 = new Ventana1();
        ShowPanel(v1);
        
        BOTONVOLVER1.setVisible(false);
        
        ventanaJuego = new VentanaJuego();
        ventanaJuego.setVentana(this);
        v4 = new Ventana4(ventanaJuego);
        v2 = new Ventana2(this, v4, ventanaJuego);
        ShowPanel(v1);
        setLocationRelativeTo(null);
    }
    
    public Ventana4 getV4() {
        return v4;
    }
    
    public void ShowPanel(JPanel v) {
        System.out.println("Mostrando panel: " + v.getClass().getSimpleName());
        v.setSize(590, 490);
        v.setLocation(0, 0);

        Contenido.removeAll();
        Contenido.add(v, BorderLayout.CENTER);
        Contenido.revalidate();
        Contenido.repaint();
        v.repaint(); // Asegurar el repintado del panel v
        System.out.println("Panel mostrado.");
    }

    public void mostrarVentanaJuego() {
        ventanaJuego.setVisible(true);
        this.setVisible(false);
    }

    public void mostrarVentanaPrincipal() {
        this.setVisible(true);
        ventanaJuego.dispose();
        ShowPanel(v4); // Muestra Ventana4
        BOTONVOLVER1.setVisible(false);
        SALIR.setVisible(true);
        REGLAS.setVisible(true);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        INICIO = new javax.swing.JButton();
        REGLAS = new javax.swing.JButton();
        SALIR = new javax.swing.JButton();
        BOTONVOLVER1 = new javax.swing.JButton();
        Contenido = new javax.swing.JPanel();
        IMG2 = new javax.swing.JLabel();
        IMG3 = new javax.swing.JLabel();
        TITULO1 = new javax.swing.JLabel();
        TITULO2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(194, 192, 193));
        jPanel3.setAutoscrolls(true);
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));

        INICIO.setBackground(new java.awt.Color(0, 102, 0));
        INICIO.setFont(new java.awt.Font("Wide Latin", 0, 18)); // NOI18N
        INICIO.setForeground(new java.awt.Color(194, 192, 193));
        INICIO.setText("INICIO");
        INICIO.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        INICIO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                INICIOActionPerformed(evt);
            }
        });

        REGLAS.setBackground(new java.awt.Color(0, 0, 255));
        REGLAS.setFont(new java.awt.Font("Wide Latin", 0, 18)); // NOI18N
        REGLAS.setForeground(new java.awt.Color(194, 192, 193));
        REGLAS.setText("REGLAS");
        REGLAS.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        REGLAS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                REGLASMouseClicked(evt);
            }
        });

        SALIR.setBackground(new java.awt.Color(204, 0, 0));
        SALIR.setFont(new java.awt.Font("Wide Latin", 0, 18)); // NOI18N
        SALIR.setForeground(new java.awt.Color(194, 192, 193));
        SALIR.setText("SALIR");
        SALIR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SALIR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SALIRMouseClicked(evt);
            }
        });
        SALIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SALIRActionPerformed(evt);
            }
        });

        BOTONVOLVER1.setBackground(new java.awt.Color(51, 51, 51));
        BOTONVOLVER1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/GUI/Imagenes/return-arrow-go-back-icon-260nw-1671444874 (1) (1).jpg"))); // NOI18N
        BOTONVOLVER1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BOTONVOLVER1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BOTONVOLVER1MouseClicked(evt);
            }
        });
        BOTONVOLVER1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOTONVOLVER1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(REGLAS, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SALIR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(INICIO, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(826, 826, 826))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(BOTONVOLVER1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(INICIO, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(REGLAS, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SALIR, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                .addComponent(BOTONVOLVER1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66))
        );

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 190, 490));

        Contenido.setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout ContenidoLayout = new javax.swing.GroupLayout(Contenido);
        Contenido.setLayout(ContenidoLayout);
        ContenidoLayout.setHorizontalGroup(
            ContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
        );
        ContenidoLayout.setVerticalGroup(
            ContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 490, Short.MAX_VALUE)
        );

        jPanel3.add(Contenido, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 210, 610, 490));

        IMG2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/GUI/Imagenes/16fa80c64f57b4363dd24dcd51e864e6.jpg"))); // NOI18N
        jPanel3.add(IMG2, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 0, 190, 210));

        IMG3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/GUI/Imagenes/16fa80c64f57b4363dd24dcd51e864e6.jpg"))); // NOI18N
        jPanel3.add(IMG3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-60, 0, 240, 210));

        TITULO1.setFont(new java.awt.Font("Wide Latin", 0, 28)); // NOI18N
        TITULO1.setText("BUSCAMINAS");
        jPanel3.add(TITULO1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 390, 50));

        TITULO2.setFont(new java.awt.Font("Wide Latin", 0, 60)); // NOI18N
        TITULO2.setText("METRO");
        jPanel3.add(TITULO2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, 450, 110));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void INICIOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_INICIOActionPerformed
        v2 = new Ventana2(this, v4, ventanaJuego); // Pasar la instancia de v4
        ShowPanel(v2);
        BOTONVOLVER1.setVisible(true);
        SALIR.setVisible(false);
        REGLAS.setVisible(false);
    
    }//GEN-LAST:event_INICIOActionPerformed

    private void SALIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SALIRActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SALIRActionPerformed

    private void SALIRMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SALIRMouseClicked
        System.exit(0);
    }//GEN-LAST:event_SALIRMouseClicked

    private void BOTONVOLVER1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOTONVOLVER1ActionPerformed
     // Ocultar el botón al inicio
    }//GEN-LAST:event_BOTONVOLVER1ActionPerformed

    private void BOTONVOLVER1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BOTONVOLVER1MouseClicked
        Ventana1 v1 = new Ventana1();
         ShowPanel(v1);
         BOTONVOLVER1.setVisible(false);
         SALIR.setVisible(true);
         REGLAS.setVisible(true);
         INICIO.setVisible(true);
    }//GEN-LAST:event_BOTONVOLVER1MouseClicked

    private void REGLASMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_REGLASMouseClicked
        Ventana3 v3 = new Ventana3();
         ShowPanel(v3);
         BOTONVOLVER1.setVisible(true);
         SALIR.setVisible(false);
         INICIO.setVisible(false);
    }//GEN-LAST:event_REGLASMouseClicked
    
    public void setBotonVolverVisible(boolean visible) {
        BOTONVOLVER1.setVisible(visible);
    }

    public void setSalirVisible(boolean visible) {
        SALIR.setVisible(visible);
    }

    public void setReglasVisible(boolean visible) {
        REGLAS.setVisible(visible);
    }

    public void setInicioVisible(boolean visible) {
        INICIO.setVisible(visible);
    }
 
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Ventana().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BOTONVOLVER1;
    private javax.swing.JPanel Contenido;
    private javax.swing.JLabel IMG2;
    private javax.swing.JLabel IMG3;
    private javax.swing.JButton INICIO;
    private javax.swing.JButton REGLAS;
    private javax.swing.JButton SALIR;
    private javax.swing.JLabel TITULO1;
    private javax.swing.JLabel TITULO2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    // End of variables declaration//GEN-END:variables

}
