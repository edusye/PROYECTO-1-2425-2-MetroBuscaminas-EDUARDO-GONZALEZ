/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

import Grafo.Casilla;
import Grafo.Tablero;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import javax.swing.Timer;
import javax.swing.filechooser.FileNameExtensionFilter;
/**
 *
 * @author edusye
 */
public class VentanaJuego extends javax.swing.JFrame {
    private ImageIcon iconoMina;
    private ImageIcon icono0;
    private ImageIcon icono1;
    private ImageIcon icono2;
    private ImageIcon icono3;
    private ImageIcon iconoBanderin;
    private int banderasColocadas = 0;

    private Tablero tableroJuego;
    private final Timer temporizador;
    private int segundosTranscurridos;
    private JButton[][] botones;
    private boolean[][] revelado;
    private int filas;
    private int columnas;
    private int numMinas;
    private boolean juegoTerminado;
    private Ventana ventana;
    
   
    
    public VentanaJuego() {
        setUndecorated(true);
        initComponents();
        cargarIconos();
        segundosTranscurridos = 0;
        temporizador = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                segundosTranscurridos++;
                CONTADOR.setText(segundosTranscurridos + "");
            }
        });
        setLocationRelativeTo(null);
    }
    
     private void cargarIconos() {
        int anchoIcono = 30; // Ajusta el ancho deseado
        int altoIcono = 30; // Ajusta el alto deseado

        iconoMina = redimensionarIcono("/GUI/Imagenes/mina.png", anchoIcono, altoIcono);
        System.out.println("Icono mina cargado: " + (iconoMina != null)); // Línea de depuración
        icono0 = redimensionarIcono("/GUI/Imagenes/numero0.png", anchoIcono, altoIcono);
        System.out.println("Icono 0 cargado: " + (icono0 != null)); // Línea de depuración
        icono1 = redimensionarIcono("/GUI/Imagenes/numero1.png", anchoIcono, altoIcono);
        System.out.println("Icono 1 cargado: " + (icono0 != null)); // Línea de depuración
        icono2 = redimensionarIcono("/GUI/Imagenes/numero2.png", anchoIcono, altoIcono);
        System.out.println("Icono 2 cargado: " + (icono0 != null)); // Línea de depuración
        icono3 = redimensionarIcono("/GUI/Imagenes/numero3.png", anchoIcono, altoIcono);
        System.out.println("Icono 3 cargado: " + (icono0 != null)); // Línea de depuración
        iconoBanderin = redimensionarIcono("/GUI/Imagenes/banderin.png", anchoIcono, altoIcono);
        System.out.println("Icono banderin cargado: " + (iconoBanderin != null)); // Línea de depuración
    }

    private ImageIcon redimensionarIcono(String ruta, int ancho, int alto) {
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource(ruta));
        Image imagenOriginal = iconoOriginal.getImage();
        Image imagenRedimensionada = imagenOriginal.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenRedimensionada);
    }
    
    public void iniciarJuego(int filas, int columnas, int minas) {
        segundosTranscurridos = 0; // Reiniciar el contador
        CONTADOR.setText("0"); // Actualizar la etiqueta del contador
        crearTablero(filas, columnas, minas);
        temporizador.start(); // Iniciar el temporizador
    }

    public void terminarJuego() {
        finDelJuego(false); 
    }
    
    public void crearTablero(int filas, int columnas, int minas) {
       this.filas = filas;
        this.columnas = columnas;
        this.numMinas = minas;
        this.juegoTerminado = false;
        banderasColocadas = 0;

        Tablero.removeAll();
        Tablero.setLayout(new GridLayout(filas, columnas));

        botones = new JButton[filas][columnas];
        revelado = new boolean[filas][columnas];
        tableroJuego = new Tablero(filas, columnas, minas, this);

        inicializarBotones(); // Llamar a inicializarBotones() aquí

        Tablero.revalidate();
        Tablero.repaint();
        pack();
    }
    
    private void inicializarBotones() {
        Color grisOscuro = new Color(50, 50, 50);

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                botones[i][j] = new JButton();
                botones[i][j].setBackground(grisOscuro);
                botones[i][j].setOpaque(true);
                botones[i][j].setBorderPainted(false);

                final int fila = i;
                final int columna = j;
                botones[i][j].addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        if (SwingUtilities.isRightMouseButton(e)) {
                            marcarDesmarcar(fila, columna);
                        } else {
                            if (!juegoTerminado) {
                                clickBoton(fila, columna);
                            }
                        }
                    }
                });

                Tablero.add(botones[i][j]);
            }
        }
    }
    
    private void clickBoton(int fila, int columna) {
        tableroJuego.revelarCasilla(fila, columna);
    }


    public void actualizarTablero() {
        for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            Casilla casilla = tableroJuego.obtenerCasilla(i, j);
            if (casilla.revelada) {
                if (casilla.esMina) {
                    botones[i][j].setIcon(iconoMina);
                    System.out.println("Icono asignado a (" + i + ", " + j + "): mina");
                } else {
                    int numeroAdyacentes = casilla.numeroAdyacentes;
                    switch (numeroAdyacentes) {
                        case 0:
                            botones[i][j].setIcon(icono0);
                            System.out.println("Icono asignado a (" + i + ", " + j + "): 0");
                            break;
                        case 1:
                            botones[i][j].setIcon(icono1);
                            System.out.println("Icono asignado a (" + i + ", " + j + "): 1");
                            break;
                        case 2:
                            botones[i][j].setIcon(icono2);
                            System.out.println("Icono asignado a (" + i + ", " + j + "): 2");
                            break;
                        case 3:
                            botones[i][j].setIcon(icono3);
                            System.out.println("Icono asignado a (" + i + ", " + j + "): 3");
                            break;
                        default:
                            botones[i][j].setText(String.valueOf(numeroAdyacentes));
                            System.out.println("Texto asignado a (" + i + ", " + j + "): " + numeroAdyacentes);
                            break;
                    }
                }
            } else if (casilla.marcada) {
                botones[i][j].setIcon(iconoBanderin);
                System.out.println("Icono asignado a (" + i + ", " + j + "): banderin");
            } else {
                botones[i][j].setIcon(null);
                System.out.println("Icono asignado a (" + i + ", " + j + "): null");
            }
        }
    }
    Tablero.revalidate();
    Tablero.repaint();
}

    public void finDelJuego(boolean ganado) {
        juegoTerminado = true;
        temporizador.stop();
        if (ganado) {
        Object[] options = {"Volver a Intentar", "Salir"};
        int opcion = JOptionPane.showOptionDialog(this, "¡Has ganado!\nTardaste solo: " + segundosTranscurridos + " segundos.", "Fin del Juego", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
        if (opcion == JOptionPane.YES_OPTION) {
            ventana.mostrarVentanaPrincipal();
        } else {
            System.exit(0);
        }
    } else {
        tableroJuego.revelarTodasLasMinas();
        SwingUtilities.invokeLater(() -> {
            actualizarTablero();
            Object[] options = {"Volver a Intentar", "Salir"};
            int opcion = JOptionPane.showOptionDialog(this, "¡Has perdido!", "Fin del Juego", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
            if (opcion == JOptionPane.YES_OPTION) {
                ventana.mostrarVentanaPrincipal();
            } else {
              System.exit(0); 
            }
        });
    }
}
    
    
    public void setVentana(Ventana ventana) {
        this.ventana = ventana;
    }

    private void marcarDesmarcar(int fila, int columna) {
        Casilla casilla = tableroJuego.obtenerCasilla(fila, columna);
        if (!casilla.revelada) {
            if (casilla.marcada) {
                casilla.marcada = false;
                banderasColocadas--;
                botones[fila][columna].setIcon(null);
            } else if (banderasColocadas < numMinas) {
                casilla.marcada = true;
                banderasColocadas++;
                botones[fila][columna].setIcon(iconoBanderin);
            }
        }
    }
    

    private void guardarJuego() {
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos CSV (*.csv)", "csv");
        fileChooser.setFileFilter(filter);

        int seleccion = fileChooser.showSaveDialog(this);

        if (seleccion == JFileChooser.APPROVE_OPTION) {
            String rutaArchivo = fileChooser.getSelectedFile().getAbsolutePath();
            if (!rutaArchivo.toLowerCase().endsWith(".csv")) {
                rutaArchivo += ".csv";
            }

            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(rutaArchivo), StandardCharsets.UTF_8))) {
                // Guardar temporizador
                writer.write(segundosTranscurridos + "\n");

                // Guardar dimensiones del tablero
                writer.write(filas + " " + columnas + " " + numMinas + "\n");

                // Guardar estado del tablero
                for (int i = 0; i < filas; i++) {
                    for (int j = 0; j < columnas; j++) {
                        Casilla casilla = tableroJuego.obtenerCasilla(i, j);
                        writer.write(casilla.esMina + " ");
                        writer.write(casilla.revelada + " ");
                        writer.write(casilla.marcada + " ");
                        writer.write(casilla.numeroAdyacentes + "");
                        if (j < columnas - 1) {
                            writer.write(" "); // Espacio en blanco como delimitador
                        }
                    }
                    writer.newLine();
                }
                JOptionPane.showMessageDialog(this, "Juego guardado correctamente.", "Guardar Juego", JOptionPane.INFORMATION_MESSAGE);

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error al guardar el juego: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    
    

    public void cargarJuego() throws IOException {
    JFileChooser fileChooser = new JFileChooser();
    FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos CSV (*.csv)", "csv");
    fileChooser.setFileFilter(filter);

    int seleccion = fileChooser.showOpenDialog(this);

    if (seleccion == JFileChooser.APPROVE_OPTION) {
        String rutaArchivo = fileChooser.getSelectedFile().getAbsolutePath();

        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            // Cargar temporizador
            segundosTranscurridos = Integer.parseInt(reader.readLine());
            CONTADOR.setText(segundosTranscurridos + "");

            // Cargar dimensiones del tablero
            String dimensionesLine = reader.readLine();
            if (dimensionesLine == null) {
                JOptionPane.showMessageDialog(this, "Error: Archivo de juego incompleto (falta dimensiones).", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String[] dimensiones = dimensionesLine.split("\\s+");
            if (dimensiones.length < 3) {
                JOptionPane.showMessageDialog(this, "Error: Archivo de juego corrupto (formato de dimensiones incorrecto).", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                filas = Integer.parseInt(dimensiones[0]);
                columnas = Integer.parseInt(dimensiones[1]);
                numMinas = Integer.parseInt(dimensiones[2]);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error: Archivo de juego corrupto (dimensiones no válidas).", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Configurar el GridLayout del Tablero
            Tablero.setLayout(new GridLayout(filas, columnas));

            // Inicializar la matriz botones después de cargar las dimensiones
            botones = new JButton[filas][columnas];

            // Cargar estado del tablero
            tableroJuego = new Tablero(filas, columnas, numMinas, this);

            for (int i = 0; i < filas; i++) {
                String[] casillas = reader.readLine().split("\\s+");
                for (int j = 0; j < columnas; j++) {
                    Casilla casilla = tableroJuego.obtenerCasilla(i, j);
                    casilla.esMina = Boolean.parseBoolean(casillas[j * 4]);
                    casilla.revelada = Boolean.parseBoolean(casillas[(j * 4) + 1]);
                    casilla.marcada = Boolean.parseBoolean(casillas[(j * 4) + 2]);
                    casilla.numeroAdyacentes = Integer.parseInt(casillas[(j * 4) + 3]);
                }
            }

            inicializarBotones(); // Llamada a inicializar botones

            actualizarTablero(); // Llamar a actualizarTablero() aquí
            
            temporizador.start();
            // Mostrar VentanaJuego (si es necesario)
            this.setVisible(true);

            JOptionPane.showMessageDialog(this, "Juego cargado correctamente.", "Cargar Juego", JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar el juego: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        GUARDAR = new javax.swing.JButton();
        SALIR = new javax.swing.JButton();
        CONTADOR = new javax.swing.JLabel();
        Tablero = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));

        GUARDAR.setBackground(new java.awt.Color(0, 102, 0));
        GUARDAR.setFont(new java.awt.Font("Wide Latin", 0, 8)); // NOI18N
        GUARDAR.setText("GUARDAR");
        GUARDAR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        GUARDAR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GUARDARMouseClicked(evt);
            }
        });

        SALIR.setBackground(new java.awt.Color(204, 0, 0));
        SALIR.setFont(new java.awt.Font("Wide Latin", 0, 8)); // NOI18N
        SALIR.setText("SALIR");
        SALIR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SALIR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SALIRMouseClicked(evt);
            }
        });

        CONTADOR.setFont(new java.awt.Font("Wide Latin", 0, 12)); // NOI18N
        CONTADOR.setText("0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SALIR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 210, Short.MAX_VALUE)
                .addComponent(CONTADOR)
                .addGap(180, 180, 180)
                .addComponent(GUARDAR)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CONTADOR)
                    .addComponent(GUARDAR)
                    .addComponent(SALIR))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 610, 60));

        Tablero.setBackground(new java.awt.Color(102, 102, 102));
        Tablero.setLayout(new java.awt.GridLayout(1, 0));
        jPanel1.add(Tablero, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 610, 430));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SALIRMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SALIRMouseClicked
         System.exit(0);
    }//GEN-LAST:event_SALIRMouseClicked

    private void GUARDARMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GUARDARMouseClicked
        guardarJuego();
    }//GEN-LAST:event_GUARDARMouseClicked

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel CONTADOR;
    private javax.swing.JButton GUARDAR;
    private javax.swing.JButton SALIR;
    private javax.swing.JPanel Tablero;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
