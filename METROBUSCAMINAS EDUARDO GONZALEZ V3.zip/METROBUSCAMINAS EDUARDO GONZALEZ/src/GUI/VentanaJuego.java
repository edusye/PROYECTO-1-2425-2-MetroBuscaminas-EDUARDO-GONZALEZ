/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

import Grafo.Casilla;
import Grafo.Tablero;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
/**
 *
 * @author edusye
 */
public class VentanaJuego extends javax.swing.JFrame {

    private Tablero tableroJuego;
    private final Timer temporizador;
    private int segundosTranscurridos;
    private JButton[][] botones;
    private boolean[][] revelado;
    private int filas;
    private int columnas;
    private int numMinas;
    private boolean juegoTerminado;

    
    public VentanaJuego() {
        initComponents();
        segundosTranscurridos = 0;
        temporizador = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                segundosTranscurridos++;
                CONTADOR.setText(segundosTranscurridos + "");
            }
        });
        temporizador.start();
    }
    
    
    public void iniciarJuego(int filas, int columnas, int minas) {
        crearTablero(filas, columnas, minas);
    }

    public void terminarJuego() {
        finDelJuego(false); 
    }
    
    public void crearTablero(int filas, int columnas, int minas) {
        this.filas = filas;
        this.columnas = columnas;
        this.numMinas = minas;
        this.juegoTerminado = false;

        Tablero.removeAll(); // Usar el panel Tablero de NetBeans
        Tablero.setLayout(new GridLayout(filas, columnas)); // Usar GridLayout en Tablero

        botones = new JButton[filas][columnas];
        revelado = new boolean[filas][columnas];
        tableroJuego = new Tablero(filas, columnas, minas, this);

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                botones[i][j] = new JButton();
                final int fila = i;
                final int columna = j;
                botones[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (!juegoTerminado) {
                            clickBoton(fila, columna);
                        }
                    }
                });
                Tablero.add(botones[i][j]); // Agregar botones a Tablero
            }
        }
        Tablero.revalidate();
        Tablero.repaint();
        pack();
    }

    private void clickBoton(int fila, int columna) {
        tableroJuego.revelarCasilla(fila, columna);
    }

    public void actualizarTablero() {
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                Casilla casilla = tableroJuego.obtenerCasilla(i, j);
                if (casilla.revelada) {
                    if (casilla.esMina) {
                        botones[i][j].setText("M");
                    } else {
                        botones[i][j].setText(String.valueOf(casilla.numeroAdyacentes));
                    }
                }
                if (casilla.marcada){
                    botones[i][j].setText("F");
                }
            }
        }
    }

    public void finDelJuego(boolean ganado) {
        juegoTerminado = true;
        if (ganado) {
            JOptionPane.showMessageDialog(this, "¡Has ganado!");
        } else {
            JOptionPane.showMessageDialog(this, "¡Has perdido!");
            revelarTodasLasMinas();
        }
    }

    private void revelarTodasLasMinas() {
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                Casilla casilla = tableroJuego.obtenerCasilla(i, j);
                if (casilla.esMina) {
                    botones[i][j].setText("M");
                }
            }
        }
    }
    

     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        SALIRYGUARDAR = new javax.swing.JButton();
        SALIR = new javax.swing.JButton();
        CONTADOR = new javax.swing.JLabel();
        Tablero = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));

        SALIRYGUARDAR.setBackground(new java.awt.Color(0, 102, 0));
        SALIRYGUARDAR.setFont(new java.awt.Font("Wide Latin", 0, 8)); // NOI18N
        SALIRYGUARDAR.setText("GUARDAR");
        SALIRYGUARDAR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        SALIR.setBackground(new java.awt.Color(204, 0, 0));
        SALIR.setFont(new java.awt.Font("Wide Latin", 0, 8)); // NOI18N
        SALIR.setText("SALIR");
        SALIR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SALIR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SALIRMouseClicked(evt);
            }
        });

        CONTADOR.setFont(new java.awt.Font("Wide Latin", 0, 12)); // NOI18N
        CONTADOR.setText("0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SALIR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 210, Short.MAX_VALUE)
                .addComponent(CONTADOR)
                .addGap(180, 180, 180)
                .addComponent(SALIRYGUARDAR)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CONTADOR)
                    .addComponent(SALIRYGUARDAR)
                    .addComponent(SALIR))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 610, 60));

        Tablero.setBackground(new java.awt.Color(102, 102, 102));
        Tablero.setLayout(new java.awt.GridLayout(1, 0));
        jPanel1.add(Tablero, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 610, 430));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SALIRMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SALIRMouseClicked
         System.exit(0);
    }//GEN-LAST:event_SALIRMouseClicked

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel CONTADOR;
    private javax.swing.JButton SALIR;
    private javax.swing.JButton SALIRYGUARDAR;
    private javax.swing.JPanel Tablero;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
