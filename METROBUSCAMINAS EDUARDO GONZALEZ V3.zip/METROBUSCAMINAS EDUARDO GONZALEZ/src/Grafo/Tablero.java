/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Grafo;

import GUI.VentanaJuego;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author edusye
 */
public class Tablero {
    public int filas;
    public int columnas;
    public int minas;
    public List<List<Nodo>> listaAdyacencias;
    public Casilla[][] casillas;
    private final VentanaJuego ventanaJuego;

    /**
     *
     * @param filas
     * @param columnas
     * @param minas
     * @param ventanaJuego
     */
    public Tablero(int filas, int columnas, int minas, VentanaJuego ventanaJuego) {
        this.filas = filas;
        this.columnas = columnas;
        this.ventanaJuego = ventanaJuego;
        if (minas > filas * columnas) {
            this.minas = filas * columnas;
            System.out.println("Advertencia: El número de minas excede el número de casillas. Se ha ajustado a " + (filas * columnas));
        } else {
            this.minas = minas;
        }
        this.listaAdyacencias = new ArrayList<>();
        this.casillas = new Casilla[filas][columnas];
        inicializarCasillas();
        generarGrafo();
        colocarMinas();
        calcularNumeros();
    }

    private void inicializarCasillas() {
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                casillas[i][j] = new Casilla(i, j);
            }
        }
    }

    private void generarGrafo() {
        // Crear nodos y lista de adyacencias
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                Nodo nodo = new Nodo(i, j, casillas[i][j]);
                if (listaAdyacencias.size() <= (i * columnas + j)) {
                    listaAdyacencias.add(nodo.getAdyacentes());
                }
                // Establecer adyacencias
                for (int x = Math.max(0, i - 1); x <= Math.min(filas - 1, i + 1); x++) {
                    for (int y = Math.max(0, j - 1); y <= Math.min(columnas - 1, j + 1); y++) {
                        if (x != i || y != j) {
                            listaAdyacencias.get(i * columnas + j).add(new Nodo(x, y, casillas[x][y]));
                        }
                    }
                }
            }
        }
    }

    private void colocarMinas() {
        Random random = new Random();
        int minasColocadas = 0;
        while (minasColocadas < minas) {
            int fila = random.nextInt(filas);
            int columna = random.nextInt(columnas);
            if (!casillas[fila][columna].esMina) {
                casillas[fila][columna].esMina = true;
                minasColocadas++;
            }
        }
    }

    private void calcularNumeros() {
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (!casillas[i][j].esMina) {
                    int contadorMinas = 0;
                    for (Nodo adyacente : listaAdyacencias.get(i * columnas + j)) {
                        if (adyacente.casilla.esMina) {
                            contadorMinas++;
                        }
                    }
                    casillas[i][j].numeroAdyacentes = contadorMinas;
                }
            }
        }
    }

    public void revelarCasilla(int fila, int columna) {
        Casilla casilla = casillas[fila][columna];
        if (!casilla.revelada && !casilla.marcada) {
            casilla.revelar();
            if (casilla.esMina) {
                if (ventanaJuego != null) { // Verificar si ventanaJuego no es nulo
                    ventanaJuego.finDelJuego(false); // Fin del juego: perdió
                }
            } else if (casilla.numeroAdyacentes == 0) {
                revelarAdyacentes(fila, columna);
            }
            if (ventanaJuego != null) { // Verificar si ventanaJuego no es nulo
                ventanaJuego.actualizarTablero(); // Actualizar la interfaz
            }
            verificarGanador(); // Verificar si ganó
        }
    }

    private void revelarAdyacentes(int fila, int columna) {
    for (Nodo adyacente : listaAdyacencias.get(fila * this.columnas + columna)) {
        Casilla casillaAdyacente = adyacente.casilla;
        if (!casillaAdyacente.revelada && !casillaAdyacente.marcada) {
            casillaAdyacente.revelar();
            if (casillaAdyacente.numeroAdyacentes == 0) {
                revelarAdyacentes(adyacente.fila, adyacente.columna);
                }
            }
        }
    }


    
    public void marcarCasilla(int fila, int columna) {
        Casilla casilla = casillas[fila][columna];
    if (!casilla.revelada) {
        casilla.marcada = !casilla.marcada;
        if (ventanaJuego != null) { // Verificar si ventanaJuego no es nulo
            ventanaJuego.actualizarTablero(); // Actualizar la interfaz
            }
        }
    }
    
    public Casilla obtenerCasilla(int fila, int columna) {
        return casillas[fila][columna];
    }
    
    private void verificarGanador() {
        int casillasReveladas = 0;
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            if (casillas[i][j].revelada) {
                casillasReveladas++;
            }
        }
    }
    if (casillasReveladas == filas * columnas - minas) {
        if (ventanaJuego != null) { // Verificar si ventanaJuego no es nulo
            ventanaJuego.finDelJuego(true); // Fin del juego: ganó
            }
        }
    }
}
