/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Grafo;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author edusye
 */
public class Nodo {

    public int fila;
    public int columna;
    public Casilla casilla;
    public List<Nodo> adyacentes;

    public Nodo(int fila, int columna, Casilla casilla) {
        this.fila = fila;
        this.columna = columna;
        this.casilla = casilla;
        this.adyacentes = new ArrayList<>(); // Inicializa la lista aquí
    }

    public void agregarAdyacente(Nodo nodo) {
        this.adyacentes.add(nodo);
    }

    public List<Nodo> getAdyacentes(){
        return this.adyacentes;
    }
}
