/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Grafo;

/**
 *
 * @author edusye
 */
public class Casilla {
 public int fila;
    public int columna;
    public boolean esMina;
    public int numeroAdyacentes;
    public boolean revelada;
    public boolean marcada;

    public Casilla(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
        this.esMina = false;
        this.numeroAdyacentes = 0;
        this.revelada = false;
        this.marcada = false;
    }

    public void revelar() {
        this.revelada = true;
    }

    public void marcar() {
        this.marcada = true;
    }
}
