/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Buscaminas;

import GUI.Ventana1;

/**
 *
 * @author edusye
 */
public class Main {
    public static void main(String []argas) {
        Ventana1 v1 = new Ventana1();
        v1.setVisible(true);
        v1.setLocationRelativeTo(null);
        
        
    }
}
